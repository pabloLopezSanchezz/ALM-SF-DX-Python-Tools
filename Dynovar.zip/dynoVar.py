import json
from modules.utils.variables.ENVS import ENVS_LIST
import difflib
import os

SRC_FOLDER = "srcToDeploy"

def main():
    componentFolders = loadDescribe()
    
    metadataFolder = input("1- Component folder name:\n ").strip()
    while metadataFolder not in componentFolders:
        close_match = difflib.get_close_matches(metadataFolder.lower(), componentFolders.keys())
        if close_match:
            print(f"Folder {metadataFolder} did not exist, Did you mean {close_match}?")
        else:
            print(f"Folder {metadataFolder} did not exist, try again.")
        metadataFolder = input("1- Component folder name:\n ").strip()

    
    varInFile = input("2- Name of dynamic var in SF component:\n ").strip()
    while not varInFile.startswith("{env.") or not varInFile.endswith("}"):
        print("Error, SF variables must follows the next syntax: {env.YOUR_VAR}")
        varInFile = input("2- Name of dynamic var in SF component:\n ").strip()
        
    varInEnvFile = "SF_" + input("3- Name of global var:\n ").strip()
    varInEnvFile = varInEnvFile.replace("SF_SF_", "SF_") if varInEnvFile.startswith("SF_SF_") else varInEnvFile
    generateSFDXDict(metadataFolder, varInEnvFile, varInFile)
    
    for env in ENVS_LIST:
        valueInEnvFile  = input(f"Value of var '{varInEnvFile}' on {env}:\n").strip()
        generateEnvFile(env, varInEnvFile, valueInEnvFile)
    
def generateEnvFile(enviroment, varInEnvFile, valueInEnvFile):
    duplicateVar = False

    if not os.path.exists("ORGS"):
        os.makedirs("ORGS")

    if os.path.isfile(f"ORGS/.env.{enviroment}"):
        with open(f"ORGS/.env.{enviroment}","r+", encoding="UTF8") as envFile:
            linesList = envFile.readlines()
            for number,line in enumerate(linesList):
                try:
                    var, value = line.split('="')
                    if varInEnvFile in var:
                        duplicateVar = True
                        sfdxVarReplacement = input(f"Duplicate var '{varInEnvFile}' in {enviroment}, do you want to replace? (Y/N)")
                        if 'Y' == sfdxVarReplacement:
                            indexToReplace = number
                        break
                except ValueError:
                    pass
            # print("linesList", linesList)
            # print("indexToReplace", indexToReplace)
            # if 'Y' == sfdxVarReplacement:
            #     linesList.pop(indexToReplace)
            #     linesList.append(f'export {varInEnvFile}="{valueInEnvFile}"')
            #     envFile.seek(0)
            #     envFile.writelines(linesList)
                
    if not duplicateVar:
        with open(f"ORGS/.env.{enviroment}","a+") as envFile:
            envFile.write(f'\n {varInEnvFile}="{valueInEnvFile}"')

def generateSFDXDict(metadataFolder, varInEnvFile, varInFile):
    sfdxProject = open("sfdx-project.json","r+")
    sfdxJson = json.loads(sfdxProject.read())
    sameFolder = False
    sameVarInFile = False
    sameVarInEnvFile = False
    
    if "replacements" not in sfdxJson.keys():
        sfdxJson["replacements"] = list(dict())    
    if sfdxJson["replacements"]:
        for replacement in sfdxJson["replacements"]:
            if metadataFolder in replacement["glob"]:
                sameFolder = True
            if varInFile == replacement["stringToReplace"]:
                sameVarInFile = True
            if varInEnvFile == replacement["replaceWithEnv"]:
                sameVarInEnvFile = True
            if sameFolder and (sameVarInEnvFile or sameVarInFile):
                break
            else:
                sameFolder = False
                sameVarInFile = False
                sameVarInEnvFile = False
    
    if not sameFolder and (not sameVarInEnvFile and not sameVarInFile):
        newReplacement = dict()
        if folderCheck(f"{SRC_FOLDER}{metadataFolder}"):
            newReplacement["glob"]=f"{SRC_FOLDER}{metadataFolder}/**"
        else:
            newReplacement["glob"]=f"{SRC_FOLDER}{metadataFolder}/*"
        newReplacement["stringToReplace"]=varInFile
        newReplacement["replaceWithEnv"]=varInEnvFile
        
        sfdxReplacements = sfdxJson["replacements"]
        sfdxReplacements.append(newReplacement)
        sfdxJson["replacements"] = sfdxReplacements
        sfdxProject.close()
    else:
        print(f"For '{varInFile}' or '{varInEnvFile}' a current assignation exists, check sfdx-project.json")
        sfdxProject.close()
        exit(1)
        
    with open("sfdx-project.json","w") as sfdxProject:
        sfdxProject.write(json.dumps(sfdxJson, indent=2))
        

def folderCheck(path):
      # Verificar si el path existe
  if os.path.exists(path):
    # Verificar si el path es una carpeta
    if os.path.isdir(path):
      # Obtener la lista de archivos y carpetas en el path
      lista = os.listdir(path)
      # Recorrer la lista y verificar si hay alguna carpeta
      for elemento in lista:
        # Componer el path completo del elemento
        elemento_path = os.path.join(path, elemento)
        # Verificar si el elemento es una carpeta
        if os.path.isdir(elemento_path):
          # Devolver True si se encuentra una carpeta
          return True
      # Devolver False si no se encuentra ninguna carpeta
      return False
    else:
      # Devolver False si el path no es una carpeta
      return False
  else:
    # Devolver False si el path no existe
    return False         

def loadDescribe():
    componentsFoldersDict = dict()
    with open("describe.log","r+") as f:
        describe = json.loads(f.read())
    for metadataObjects in describe["metadataObjects"]:
        try:
            componentsFoldersDict[metadataObjects["directoryName"]] = metadataObjects["suffix"]
        except KeyError:
            componentsFoldersDict[metadataObjects["directoryName"]] = None
    return componentsFoldersDict
if __name__ == "__main__":
    main()