import os
import xml.etree.ElementTree as ET
import re
from modules.utils.argsParser import parseArgs
from modules.validator.classesValidation import checkClass
from modules.utils.utilities import checkNomenclatureGeneral, generate_html, checkDescription
from modules.validator.objectsValidation import checkCustomObject


def nomenclatureValidator(pathToSrc):
    incorrectLWC = []
    incorrectAPR = []
    incorrectVFP = []
    incorrectOBJ = []
    incorrectFLD = []
    incorrectVLR = []
    incorrectRTP = []
    incorrectCLS = []
    incorrectTest = []
    incorrectTRG = []
    objToDeploy = []
    incorrectDescription = []
    incorrectDescFields = []
    incorrectDescObjects = []
    incorrectDescLayouts = []
    incorrectDescVLR = []


    validEndingsClasses = ['VFController', 'Controller', 'Extension', 'Handler', 'Util', 'TriggerHandler', 'Batch', 'Scheduler', 'Queue']

    for folder in os.listdir(pathToSrc):
        print( f'Validating {folder}' )
                
        #for fileName in os.listdir(f'{pathToSrc}/{folder}'):
        for fileName in os.listdir(os.path.join(pathToSrc,folder)):
            if 'objects' in folder:
                checkCustomObject(pathToSrc, folder, fileName,objToDeploy, incorrectOBJ, incorrectFLD, incorrectVLR, incorrectRTP, incorrectDescObjects, incorrectDescFields, incorrectDescVLR)

            elif 'approvalProcesses' in folder:
                if fileName.endswith('-meta.xml'):
                    fileName = fileName.replace('-meta.xml','')
                apiName = fileName.split('.')[1]
                reportName = apiName
                checkNomenclatureGeneral(reportName, apiName, incorrectAPR)

            elif 'pages' in folder:
                if fileName.endswith('-meta.xml'):
                    fileName = fileName.replace('-meta.xml','')
                apiName = fileName.split('.')[0]
                reportName = apiName
                
                incorrectVFP = checkNomenclatureGeneral(reportName, apiName, incorrectVFP)

            elif  'lwc' in folder:
                if not fileName.split('.')[0].endswith('App'):
                    incorrectLWC.append(fileName)
                else:
                    if fileName.endswith('-meta.xml'):
                        fileName = fileName.replace('-meta.xml','')
                    apiName = fileName.split('.')[0]
                    reportName = apiName
                    
                    checkNomenclatureGeneral(reportName, apiName, incorrectLWC)

            elif 'classes' in folder:
                # Open the file
                classPath = os.path.join(pathToSrc, folder, fileName)
                if not fileName.endswith('-meta.xml'):
                    apiName = fileName.split('.')[0]
                    checkClass(classPath, apiName, validEndingsClasses, incorrectCLS, incorrectTest)
            
            elif 'triggers' in folder:
                if not fileName.endswith('-meta.xml'):
                    apiName = fileName.split('.')[0]
                    if '_' in apiName or not apiName.split('.')[0].endswith('Trigger') or not apiName[0].istitle():
                        incorrectTRG.append(apiName)

            elif 'layouts' in folder:
                pathSrc = os.path.join(pathToSrc, folder, fileName)
                apiName = fileName.split('.')[0]
                reportName = apiName
                checkDescription(pathSrc, reportName, apiName, incorrectDescLayouts)
    
    data = {
        'Approval Proccess': incorrectAPR,
        'Classes' : incorrectCLS,
        'Fields' : [
            {"Incorrect Nomenclature for Fields": incorrectFLD},
            {"Description of Fields": incorrectDescFields}
        ] if (incorrectFLD or incorrectDescFields) else [],
        'LWC': incorrectLWC,
        'Objects' : [
            {"Incorrect Nomenclature for Objects": incorrectOBJ},
            {"Description of Objects": incorrectDescObjects}
        ] if (incorrectOBJ or incorrectDescObjects) else [],
        'Pages': incorrectVFP,
        'Record Type' : incorrectRTP,
        'Tests' : incorrectTest,
        'Triggers' : incorrectTRG,
        'Validation Rules' : [
            {"Incorrect Nomenclature for Validation Rules": incorrectVLR},
            {"Description of Validation Rules": incorrectDescVLR}
        ] if (incorrectVLR or incorrectDescVLR) else [],
        'Incorrect description in Layouts' : incorrectDescLayouts
    }

    info_messages = {
        'Approval Proccess': 'Check if Approval Proccess has first letter in upercase and name does not have underscore.',
        'Classes' : 'Check if Class has first letter in upercase and name does not have underscore.',
        'Fields' : 'Check if Field has two underscore with three letter in upercase, underscore, three letter in upercase that should be specified abbreviation for every type of field (not verified), and name of field in upercase with first letter in upercase. \nAlso review if field has description tag.',
        'LWC': 'Check if LWC has first letter in upercase and name does not have underscore',
        'Objects' : 'Check if Object has first letter in upercase and name does not have underscore. Also check if has description tag and if its description tags starts with [OBJ], where OBJ depends of object',
        'Pages': 'Check if Page has first letter in upercase and name does not have underscore',
        'Record Type' : 'Check if Record Type has first letter in upercase and name does not have underscore',
        'Tests' : 'Check if Test has first letter in upercase, name finish with test and name does not have underscore',
        'Triggers' : 'Check if Trigger has first letter in upercase and name does not have underscore',
        'Validation Rules' : 'Check if Validation Rule has first letter in upercase and name does not have underscore. Also review if validation rule has description tag.',
        'Incorrect description in Layouts' : 'Check if Layout has description tag.'
    }


    generate_html(data, info_messages)


def main ():
    try:
        args = parseArgs()                                     
        
        if not os.path.isdir(args.pathToSrc):
            print('[WARNING] Path to src does not exist')
        
        print( 'Checking nomenclature' )
        nomenclatureValidator(args.pathToSrc)
        
    except Exception as e:
        print (f'no se ha podido realizar el estudio de la nomenclatura. Error: {str(e)}')
        



if  __name__ == '__main__':
    main()

